<?php
defined( '_JEXEC' ) or die( 'Restricted Access' );
?>
<p>
	Select the citation type you are looking for.
</p>
<p>
	<a href="<?php echo JRoute::_( 'index.php?option=com_gpo&controller=citations&type=news'); ?>">News</a>
</p>

<p>
	<a href="<?php echo JRoute::_( 'index.php?option=com_gpo&controller=citations&type=quotes'); ?>">Quotes</a>
</p>