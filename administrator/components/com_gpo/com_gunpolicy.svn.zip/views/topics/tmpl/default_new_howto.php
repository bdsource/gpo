<?php
defined( '_JEXEC' ) or die( 'Restricted Access' );
?>
<h1>How to create a new Topic</h1>

<ol>
<li>
	<p><a href="<?php echo JRoute::_( 'index.php?option=com_gpo&controller=news&task=search',false );?>">Create a search via &quot;News&quot;</a>, once happy with your search criteria or after seeing the results. Click the "Goto Topic" button.</p>
</li>
<li>
	<p>Edit Topic information, checking the &quot;seo&quot; field is correct.</p>
</li>
<li>
	<p>Hit Save, then click on the link to see the topic you just created in the front end.</p>
</li>
</ol>