<?php
defined( '_JEXEC' ) or die( 'Restricted Access' );
?>

<?php
echo $this->summary;
?>