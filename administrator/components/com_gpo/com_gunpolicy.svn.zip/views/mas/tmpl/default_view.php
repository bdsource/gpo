<?php
defined( '_JEXEC' ) or die( 'Restricted Access' );
?>
<h1>View</h1>

<?php echo '<pre>' . print_r( $this->oMas, true ) . '</pre>'; ?>