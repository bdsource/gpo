<?php
defined( '_JEXEC' ) or die( 'Restricted Access' );
?>
<p>
Pick a table:
</p>
<ul>
	<li>
		<a href="<?php echo JRoute::_( 'index.php?option=com_gpo&controller=cleanup&task=picker&table=j25_gpo_news'); ?>">News</a>
	</li>
</ul>
