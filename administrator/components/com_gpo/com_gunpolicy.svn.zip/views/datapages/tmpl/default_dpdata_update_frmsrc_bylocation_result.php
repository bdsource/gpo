<?php
defined( '_JEXEC' ) or die( 'Restricted Access' );
?>

<style>
    .red {
        color: red;
    }
    .green {
        color: green;
    }
    .blue {
        color: blue;
    }
    .blank {
    <?php 
    if( $this->importOnlyBlankYears ):
        echo 'background-color: lightgreen !important';
    endif;
    ?>
    }
    
    table {
        empty-cells: show !important;
    }
</style>

<?php
$document = JFactory::getDocument();
$front_end = str_replace( "administrator",'',JURI::base(true));
$frontBase = str_replace( "administrator",'',JPATH_BASE);
require_once($frontBase . '/components/com_gpo/models/region.php');
require_once(JPATH_BASE . '/components/com_gpo/models/datapages.php');
require_once($frontBase . '/components/com_gpo/helpers/datapage.php');
require_once(JPATH_BASE . '/components/com_gpo/helper/datapage.php');
$document->addScript('//ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js');
$document->addScript('//cdnjs.cloudflare.com/ajax/libs/floatthead/2.1.2/jquery.floatThead.js');

$datapageModel  = new GpoModelDatapages();
$datapageHelper = new DatapageHelper();
$regionModel    = new GpoModelRegion();

$selectedLocationDetails = $datapageModel->getLocationById($this->selectedLocation);
$dpColumnsInfo = $datapageModel->getDPColumnsInfo();
?>
<h3>
    <?php if($this->importType == 'by_location') {
        echo "⇒ Import By Location  "; 
    } else {
        echo "⇒ Import By Category  ";
    }
    if( $this->importOnlyBlankYears ) { echo " &mdash; (Only import the data for Blank Years)"; }
    ?>
</h3>
<?php 
    if($this->importOnlyBlankYears):
        echo "<h4 class='red'>⇒ ⇒ N.B: Importing Data for the Blank Years Only is set to TRUE</h4>";
    endif;
?>
 
<form action="index.php?option=com_gpo&controller=datapages" method="post" id="adminForm" name="adminForm">
    <input type="hidden" name="option" value="com_gpo" />
    <input type="hidden" name="controller" value="datapages" />
    <input type="hidden" name="task" value="<?php echo $this->task;?>" />
    <input type="hidden" name="boxchecked" value="0" />
    <input type="hidden" name="action" value="<?php echo $this->action;?>" />
    <input type="hidden" name="lang" value="<?php echo $this->currentLanguage;?>" />
    <input type="hidden" name="search_options" value="<?php echo urlencode( serialize($this->searchOptions) );?>" />
    <input type="hidden" name="importType" id="importType" value="<?php echo $this->importType;?>" />

    <table class="adminlist"  border="0" cellpadding="2" cellspacing="2" width="100%">
    <tr valign="top">
	<th width="10%">
        Data Source 
	</th>

	<th width="40%">
    	Column Info
	</th>
	
	<th width="40%">
	   Check DP FrontEnd (Preview URL)
	</th>
    </tr>
    
    <tr valign="top">
	<td width="15%">
            <strong> Data Source Name: </strong> <?php echo $this->dataSourceName;?> <br>
	</td>

	<td width="25%">
            <strong> Location Name: </strong>  <?php echo $selectedLocationDetails->name;?> <br>
            <strong> ID: </strong> <?php echo $selectedLocationDetails->id;?> <br>
            <strong> Type: </strong>  <?php echo $selectedLocationDetails->type;?> <br>
	</td>
	
	<td width="40%">
        <?php 
        $previewURL = JURI::root() . '/preview_dp.php?location='.$selectedLocationDetails->name;
        echo '<a href="' . $previewURL . '" target="_blank">' . $previewURL . '</a>';
        ?>
	</td>
    </tr>
    </table>
   
    <p> &nbsp; </p>

<?php
$currentYear = intval(date('Y'));
$years = array();
$dpNewSrcDataArray = $this->newSourceData;

##################
### Generate Years Array For Table headers
##################
if($this->importOnlyBlankYears) { ## For blank years, we only show the years present in Excel sheet
    foreach( $dpNewSrcDataArray as $key => $dpNewSrcDataYears ):
        foreach( $dpNewSrcDataYears as $key => $val ):
            if( is_integer($key) ):
                $years[] = $key;
            endif;
        endforeach;
        break; // stop after processing first element 
    endforeach;
} else {  ## Else we show all years from 1978 for the preview
    while( $currentYear >= 1978 ) {
        $years[] = $currentYear;
        $currentYear--;
    }
}

$existingDPDataEn = $this->existingDPDataEn;
?>

<p style="color:red;">
    <input type="checkbox" name="replace_en" value="1" checked disabled="1" /> Replace EN (English) DPs &nbsp;
    <input type="checkbox" name="replace_fr" value="1" checked /> Replace FR (French) DPs &nbsp;
    <input type="checkbox" name="replace_es" value="1" checked /> Replace ES (Espanol) DPs &nbsp;
</p>
<div> Color Code: 
    <span class="green">Green: Existing Values; &nbsp;</span>
    <span class="blue">Blue: New Values from Excel File; &nbsp;</span>
    <span class="red">Red: Merged Values to be updated in the DB; &nbsp;</span>
    (Tick/Select the Location Names you want to update)
</div>
<table class="adminlist table-striped table-hover table-bordered stickyHead" id="adminList" style="table-layout:auto;" cellspacing="1px" cellpadding="1px" width="100%" border="1">
    <thead>
        <tr>
            <th width="20%">Category Title</th>
            <th width="5%" valign="top" align="center">
		<input type="checkbox" name="toggle" value="" onclick="Joomla.checkAll(this);" />
            </th>
            <th width="25%" style='min-width:250px;'>Column Value</th>
            <?php
            foreach($years as $key=>$val):
                echo "<th style='max-width:95px;'>$val</th>";
            endforeach;
            ?>
        </tr>
    </thead>
    <tbody>
        <?php
            $counter = 0;
            $i = 0;
            $k = 0;
            $unknownCategories = array();
            //foreach($this->existingDPDataEn as $key => $val):
            foreach($this->newSourceData as $key => $val):
                $checked     = JHTML::_('grid.checkedout', $item, $i);
                $categoryObj = $dpColumnsInfo[$key];
                
                if( empty($categoryObj->id) ) {
                    $unknownCategories[] = $key;
                    continue;
                }
                
                $categoryObj->name = $key;
                $colVal = $existingDPDataEn->$key;
               
                $yearlyData = $datapageHelper->splitDataValueYearly($colVal);
                $yearlyDataWithoutQuotes = $datapageHelper->getYearlyDataArray($colVal);
                
                $DPEditURL  = JURI::base() . "/index.php?option=com_gpo&controller=datapages&task=view_dp";
                $DPEditURL .= '&id=' . $categoryObj->column_name . '&location=' . $selectedLocationDetails->name;
                
                echo "<tr style='color:green;' class='row$k'>
                           <td rowspan='3'>
                           <a title='Edit/View DP of ". $categoryObj->column_name ."' href='".$DPEditURL."' target='_blank'>".
                           $categoryObj->column_title."</a>
                           </td>";
                echo '<td rowspan="3" width="5%" valign="top" align="center"> '
                     . '<input id="cb' . $i . '" type="checkbox" title="Checkbox for row ' . $i . '" onclick="Joomla.isChecked(this.checked);" value="' . $categoryObj->column_name . '" name="cid['. $i . ']"> </td>';

                echo "<td width='30%' style='min-width:250px;' valign='top' align='left'>".$colVal."</td>";
                foreach($years as $k=>$v):
                    $bClass =  isset($yearlyData[$v]) ? '' : "class='blank'";
                    echo "<td style='max-width:95px;' $bClass title='".$yearlyData[$v]."'>".$yearlyData[$v]."</td>";
                endforeach;
                echo "</tr>";
                
                ###
                ### Caluculate and show new data values ### 
                ###
                $counter++;
                $newDataValues = $dpNewSrcDataArray[$categoryObj->column_name];
                $newMergedYearlyData = array();
                if( !empty($newDataValues) ) {
                    $newMergedYearlyData = mergeYearlyDataWithNewValues($yearlyData, $newDataValues, $yearlyDataWithoutQuotes, $this->importOnlyBlankYears);
                }
                $newUpdatedValue = concatYearlyDataValues($newMergedYearlyData);
                
                echo "<tr style='color:blue;'>";
                //echo '<td rowspan="2" align="center">&nbsp;</td>';
                echo "<td width='30%' style='min-width:250px;' class='red replace' valign='top' align='left' rowspan='2'> <div align='left'>". $newUpdatedValue . '</div>';
                echo '<input style="display:none;" type="text" name="category_alias['.$i.']" value="'. $categoryObj->column_name .'" class="category_alias"  />';
                echo '<textarea style="display:none;width:99%;" name="replace'.$i.'" rows="6">'.$newUpdatedValue.'</textarea>';
                echo "</td>";

                foreach($years as $k => $v):
                    $QCite = $dpNewSrcDataArray[$categoryObj->column_name]['QCite'];
                    $QCiteFormatted = '';
                    if ( !empty(trim($QCite)) ) {
                         $QCiteFormatted =  '{' . $QCite . '}';
                    }
                    if ( !empty($dpNewSrcDataArray[$categoryObj->column_name][$v]) ) {
                        $newColValue = formatNumberForYearlyData($dpNewSrcDataArray[$categoryObj->column_name][$v]).$QCiteFormatted;
                    } else {
                        $newColValue = formatNumberForYearlyData($dpNewSrcDataArray[$categoryObj->column_name][$v]);
                    }
                    echo "<td style='max-width:95px;' title='".$newColValue."'>" . $newColValue."</td>";
                endforeach;
                echo "</tr>";
                
                echo "<tr style='color:red;font-weight:bold;'>";

                foreach($years as $k => $v):
                    echo "<td style='max-width:95px;' title='".$newMergedYearlyData[$v]."'>".$newMergedYearlyData[$v]."</td>"; 
                endforeach;
                echo "</tr>";
                
                //if( $counter == 10 ) {break;}
            $i++;
            $k = 1 - $k;
            endforeach;
        ?>
    </tbody>
    
    <tfoot>
        <tr>
            <th width="10%">Category Title</th>
            <th width="5%">&nbsp;</th>
            <th width="15%">Column Value</th>
            <?php
            foreach($years as $key=>$val):
                echo "<th>$val</th>";
            endforeach;
            ?>
        </tr>
    </tfoot>
</table>

<p>
    Selected Location Name: <strong> <?php echo $selectedLocationDetails->name;?> &nbsp; &dash; &nbsp; <?php echo $selectedColumn;?></strong>
                      : <input type="hidden" name="selectedLocationId" id="selectedLocationId" value="<?php echo $selectedLocationDetails->id;?>" />
                        <input type="hidden" name="importType" id="importType" value="<?php echo $this->importType;?>" />
</p>
    

<?php
if( !empty($unknownCategories) ):
?>
<h4 class="red">
    WARNING:: Unknown Categories (name/alias) found in the Excel File. These categories are excluded from the import. Please check the spelling of: <br>
    <i> 
    <?php
        foreach( $unknownCategories as $lk => $lv ):
            echo $lv . '<br>'; 
        endforeach;
    echo '</i>';
    echo '';
    ?>
</h4>
<?php
endif;
?>
</form>

<script type="text/javascript">
jQuery.noConflict();
jQuery(document).ready(function() {
    jQuery('input[name="toggle"]').click(function(){
        var chk = jQuery(this).is(':checked');
        jQuery('.location_id').each(function(){
             jQuery(this).prop('checked', chk);
        });
    });
    
    jQuery('input[type="checkbox"]').click(function(){
        var chk = jQuery(this).is(':checked');
        jQuery(this).parent().parent().find('.location_id').prop('checked', chk);
    });
    
    //Make the table header fixed/scrollable
    jQuery('.stickyHead').floatThead({
	useAbsolutePositioning: true,
	top: 80
    });


SearchUtil = {

        onClickShowEditable: function(pSelector) {
	   jQuery(pSelector).each( function(index) {
		   jQuery(this).click( function(event) {
		      var el = jQuery(this);
                      var tagName = jQuery(this).prop('tagName');
		      if ('DIV' == tagName) {
		    	  jQuery(this).find('textarea').show();
		      }
		      else if ('TD' == tagName) {
		    	  jQuery(this).find('textarea').show();
		      }
		   });
		});
	 }
};

SearchUtil.onClickShowEditable('td.replace');

});
</script>
